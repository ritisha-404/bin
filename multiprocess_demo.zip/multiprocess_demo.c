#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    int n, i;
    printf("Enter number of child processes to create: ");
    scanf("%d", &n);

    pid_t pid;
    for (i = 0; i < n; i++) {
        pid = fork();

        if (pid < 0) {
            perror("Fork failed");
            exit(1);
        } 
        else if (pid == 0) {
            printf("Child %d (PID: %d, Parent PID: %d) running...\n", i + 1, getpid(), getppid());
            sleep(2 + i);
            printf("Child %d (PID: %d) finished its task.\n", i + 1, getpid());
            exit(0);
        }
    }

    for (i = 0; i < n; i++) {
        wait(NULL);
    }

    printf("All child processes completed. Parent PID: %d exiting.\n", getpid());
    return 0;
}